Notepadqq contributors
----------------------

Sorted alphabetically.

 * [aadityakalsi](https://github.com/aadityakalsi)
 * [danieleds](https://github.com/danieleds) - Daniele Di Sarli
 * [darealshinji](https://github.com/darealshinji)
 * [flamusdiu](https://github.com/flamusdiu)
 * [maksqwe](https://github.com/maksqwe)
 * [OpenNingia](https://github.com/OpenNingia)
 * [pcatalani](https://github.com/pcatalani)
 * [Teklad](https://github.com/Teklad)
 * [vpop](https://github.com/vpop) - Voicu Pop
