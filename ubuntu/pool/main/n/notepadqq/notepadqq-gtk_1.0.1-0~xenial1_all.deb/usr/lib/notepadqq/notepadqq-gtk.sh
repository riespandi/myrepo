#!/bin/sh
/usr/lib/notepadqq/notepadqq.sh -style=gtk "$@"
